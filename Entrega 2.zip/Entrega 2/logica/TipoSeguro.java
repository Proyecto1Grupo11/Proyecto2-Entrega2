package logica;

/**
 * <!-- DOCUMENTACION -->
 * <!--  Este enum se utiliza en la parte de reservas, para saber 
 * el incremento tarifa dependiendo del tipo de reserva  -->
 */

public enum TipoSeguro {
	
	SURA,
	COOMEVA,
	SEGUROSBOLIVAR,
	OTROSEGURO
}
