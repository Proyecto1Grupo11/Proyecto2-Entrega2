package logica;
/**
 * <!-- DOCUMENTACION!-->
 * <!-- Este enum se usa para verificar que rol se le asigna a cada usuario,
 *  si se quisiera hacer un metodo isAdmin(), o cosas asi para permsios -->
 *  
 * <!-- Para acceder a este enum: Roles.ADMINISTRADORGENERAL  -->
 * @generated
 */
public enum Roles
{
	ADMINISTRADORGENERAL, 
	ADMINISTRADORSEDE, 
	EMPLEADO, 
	CLIENTE;
	}
