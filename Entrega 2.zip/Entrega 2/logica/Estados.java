package logica;

/**
 * <!-- ACA VA DOCUMENTACION -->
 * <!--  Este enum se usa para los estados de un vehiculo.  -->
 */
public enum Estados
{
	NODISPONIBLE, 
	DISPONIBLE, 
	NECESITAMANTENIMIENTO;
}
